using UnityEngine;

[CreateAssetMenu(fileName = "NewTowerUpgrade", menuName = "TowerDefense/Upgrade")]
public class TowerUpgrade : ScriptableObject
{
    public string UpgradeName;
    [TextArea] public string Description;
    public Sprite Icon;

    public int Cost = 100;

    // Multiplicadores y bonos (1 = sin cambio)
    public float DamageMultiplier = 1f;
    public float FireRateMultiplier = 1f;
    public float RangeBonus = 0f;

    // Nueva: bonus de penetraci�n de armadura que aporta la mejora (0 = ninguno, 1 = +100%)
    [Tooltip("Porcentaje adicional de penetraci�n de armadura que aporta la mejora (0-1). Ej: 0.2 = +20%")]
    [Range(0f, 1f)]
    public float ArmorPenetrationBonus = 0f;

    // Nueva: n�mero de rebotes que aporta la mejora (para la rama B)
    [Tooltip("N�mero adicional de rebotes que aporta la mejora (0 = ninguno)")]
    [Range(0, 5)]
    public int BounceCountBonus = 0;

    // Nueva: efectos para lanzamisiles (rama A y B)
    [Tooltip("Cantidad de ralentizaci�n aplicada por la mejora (0-1). Ej: 0.2 = -20% velocidad")]
    [Range(0f, 1f)]
    public float SlowAmountBonus = 0f;

    [Tooltip("Duraci�n en segundos de la ralentizaci�n aplicada por la mejora")]
    public float SlowDurationBonus = 0f;

    [Tooltip("Aumento del radio de explosi�n que aporta la mejora (unidades del mundo, suma al radio base)")]
    public float ExplosionRadiusBonus = 0f;

    // Nueva: aumento de duraci�n de la quemadura (rama B de la lanzallamas)
    [Tooltip("Aumento en segundos de la duraci�n del efecto de quemadura que aporta la mejora")]
    public float BurnDurationBonus = 0f;

    // Estado resultante que representar� la mejora aplicada en la torre
    public TowerBehaviour.UpgradeState ResultingState;
}