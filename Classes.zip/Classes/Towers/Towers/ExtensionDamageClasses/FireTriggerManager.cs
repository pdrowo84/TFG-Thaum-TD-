using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using static ElementDamageType;

public class FireTriggerManager : MonoBehaviour
{
    [SerializeField] private FlameThrowerDamage BaseClass;


    private void OnTriggerEnter(Collider other)
    {
        Debug.Log($"[FireTrigger] Algo ha entrado: {other.name}, tag: {other.tag}");

        if (other.transform.root.CompareTag("Enemy"))
        {
            Debug.Log($"[FireTrigger] {other.name} entra en el �rea de fuego.");

            var tower = GetComponentInParent<TowerBehaviour>();
            if (tower == null)
            {
                Debug.LogError("FireTriggerManager: No se encontr� TowerBehaviour en este objeto ni en sus padres.");
                return;
            }
            ElementType damageType = tower.DamageElement;

            float burnDuration = tower.FlameBurnDuration;
            Effect FlameEffect = new Effect("Fire", BaseClass.FireRate, BaseClass.Damage, burnDuration, damageType);
            ApplyEffectData EffectData = new ApplyEffectData(EntitySummoner.EnemyTransformPairs[other.transform.parent], FlameEffect);
            GameLoopManager.EnqueueEffectToApply(EffectData);
        }
    }
}